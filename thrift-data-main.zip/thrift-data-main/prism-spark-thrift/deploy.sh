#!/bin/bash

set -eo pipefail # Exit on error and treat unset variables as error, pipefail

echo "Starting Helm deployment for Spark Thrift Server..."
echo "Release Name: ${RELEASE_NAME}"
echo "Namespace: ${NAMESPACE}"
echo "Chart Path: ${CHART_PATH}"
echo "Environment: ${ENVIRONMENT}"
echo "Docker Image Tag: ${IMAGE_TAG}"
echo "IRSA Role ARN: ${IRSA_ROLE_ARN}"
echo "Thrift JDBC Hostname: ${THRIFT_JDBC_HOSTNAME}"
echo "Spark UI Hostname: ${SPARK_UI_HOSTNAME}"
echo "Spark UI TLS Secret: ${TLS_SECRET_NAME}"
echo "Expose Spark UI via Ingress: ${EXPOSE_SPARK_UI}"
echo "S3 Warehouse Path: ${S3_WAREHOUSE_PATH}"
echo "Glue Account ID: ${GLUE_ACCOUNT_ID}"

# Basic cheks
if [ -z "${RELEASE_NAME}" ]; then echo "Error: RELEASE_NAME is not defined."; exit 1; fi
if [ -z "${NAMESPACE}" ]; then echo "Error: NAMESPACE is not defined."; exit 1; fi
if [ -z "${CHART_PATH}" ]; then echo "Error: CHART_PATH is not defined."; exit 1; fi
if [ -z "${IMAGE_TAG}" ]; then echo "Error: IMAGE_TAG is not defined."; exit 1; fi
if [ -z "${IRSA_ROLE_ARN}" ]; then echo "Error: IRSA_ROLE_ARN is not defined."; exit 1; fi
if [ -z "${S3_WAREHOUSE_PATH}" ]; then echo "Error: S3_WAREHOUSE_PATH is not defined."; exit 1; fi
if [ -z "${GLUE_ACCOUNT_ID}" ]; then echo "Error: GLUE_ACCOUNT_ID is not defined."; exit 1; fi


HELM_CMD="helm upgrade --install ${RELEASE_NAME} ${CHART_PATH}"
HELM_CMD+=" --values ${CHART_PATH}/values.yaml"
HELM_CMD+=" --namespace ${NAMESPACE}"
HELM_CMD+=" --atomic"
HELM_CMD+=" --timeout 10m"
HELM_CMD+=" --set image.tag=${IMAGE_TAG}"
HELM_CMD+=" --set serviceAccount.annotations.\"eks\\.amazonaws\\.com/role-arn\"=${IRSA_ROLE_ARN}"
HELM_CMD+=" --set sparkThriftServer.icebergWarehousePath=${S3_WAREHOUSE_PATH}"
HELM_CMD+=" --set sparkThriftServer.glueAccountId=${GLUE_ACCOUNT_ID}"

# Set values for the Trhift TCP endpoint informational in values.yaml, actual exposure is external
if [ -n "${THRIFT_JDBC_HOSTNAME}" ]; then
  HELM_CMD+=" --set internalDns.thrift.hostname=${THRIFT_JDBC_HOSTNAME}"
  HELM_CMD+=" --set service.annotations.\"external-dns\.alpha\.kubernetes\.io/hostname\"=${THRIFT_JDBC_HOSTNAME}."
fi

# Set values for Spark UI Ingress
if [ "${EXPOSE_SPARK_UI}" == "true" ]; then
  HELM_CMD+=" --set ingressSparkUI.enabled=true"
  if [ -n "${SPARK_UI_HOSTNAME}" ]; then
    HELM_CMD+=" --set internalDns.sparkUI.hostname=${SPARK_UI_HOSTNAME}" # Used by Ingress template
    HELM_CMD+=" --set ingressSparkUI.tls.enabled=true" # TLS for UI
    if [ -n "${TLS_SECRET_NAME}" ]; then
      HELM_CMD+=" --set ingressSparkUI.tls.secretName=${TLS_SECRET_NAME}"
    else
      # If platform automatio creates secret based on host, e.g., <host>-tls
      GENERATED_TLS_SECRET_NAME=$(echo "${SPARK_UI_HOSTNAME}" | tr '.' '-')-tls
      HELM_CMD+=" --set ingressSparkUI.tls.secretName=${GENERATED_TLS_SECRET_NAME}"
    fi
    # Add common annotations for Skyscrappers platform
    HELM_CMD+=" --set-string ingressSparkUI.annotations.\"kubernetes\.io/ingress\.class\"=nginx"
    HELM_CMD+=" --set-string ingressSparkUI.annotations.\"cert-manager\.io/cluster-issuer\"=letsencrypt-prod"
  fi
fi

# Execute the helm command
echo "Executing Helm command:"
echo "${HELM_CMD}"
eval "${HELM_CMD}"

exit 0